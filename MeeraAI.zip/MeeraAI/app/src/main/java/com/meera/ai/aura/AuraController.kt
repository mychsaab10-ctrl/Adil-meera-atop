package com.meera.ai.aura

import android.app.Application
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import com.meera.ai.Meera
import com.meera.ai.automation.MeeraAccessibilityService
import com.meera.ai.voice.CallState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

enum class AuraState { OFF, LISTEN, THINK, SPEAK }

/**
 * "Meera Aura" (v2.2): a premium glowing border around the screen edges that shows what Meera is doing
 * (listening / thinking / speaking) and pulses with her voice while she speaks.
 *
 * Two modes (Settings -> Meera Aura):
 *  - "app"   : the border is drawn inside the Meera app only (MainActivity adds an [AuraView] on top of its window).
 *  - "phone" : the border is drawn over every app with a touch-through overlay window (needs the
 *              "Display over other apps" permission, which only the user can grant). Without that permission the
 *              in-app border is used instead. Nothing is recorded; the overlay is just a view that draws lines.
 *
 * Voice level: for the Live call the real loudness (RMS) of the PCM audio being played is used ([feedPcm]).
 * Android's TextToSpeech gives no audio data, so while TTS speaks the pulse is a natural-looking simulated envelope.
 */
class AuraController(private val app: Application, private val scope: CoroutineScope) {
    val state = MutableStateFlow(AuraState.OFF)
    val ttsSpeaking = MutableStateFlow(false)
    /** True when the border must be drawn inside the app window (mode "app", or "phone" without permission). */
    val inApp = MutableStateFlow(false)

    @Volatile var realLevel = 0f
    @Volatile var realAt = 0L
    @Volatile var gain = 1f

    private var overlay: AuraView? = null
    private var overlayWm: WindowManager? = null
    private var overlayFailed = false

    fun start() {
        refresh()
        scope.launch {
            combine(Meera.call.state, ttsSpeaking) { c, tts ->
                val all = Meera.settings.auraAllStates
                val s = when (c) {
                    CallState.Speaking -> AuraState.SPEAK
                    CallState.Listening -> AuraState.LISTEN
                    CallState.Thinking, CallState.Connecting -> AuraState.THINK
                    else -> AuraState.OFF
                }
                when {
                    tts || s == AuraState.SPEAK -> AuraState.SPEAK
                    all -> s
                    else -> AuraState.OFF
                }
            }.collect {
                state.value = it
                refresh()
            }
        }
    }

    fun canDrawOverlays(): Boolean = try { Settings.canDrawOverlays(app) } catch (e: Exception) { false }

    /**
     * "Poore phone par" can work in two ways: (1) the normal "Display over other apps" permission, or
     * (2) Meera's Accessibility service, which Android allows to draw an overlay WITHOUT that permission
     * (useful on phones where "Display over other apps" is switched off by the manufacturer).
     */
    fun canShowOverPhone(): Boolean = canDrawOverlays() || MeeraAccessibilityService.instance != null

    /** Called by the accessibility service when it connects / disconnects, so the overlay follows. */
    fun onA11yChanged() {
        if (MeeraAccessibilityService.instance == null && overlay != null && !canDrawOverlays()) {
            overlay = null // its window disappeared together with the service
            overlayWm = null
        }
        overlayFailed = false
        refresh()
    }

    /** Call after any Aura setting changed (also clears an earlier overlay failure). */
    fun settingsChanged() {
        overlayFailed = false
        refresh()
    }

    /** Computes loudness (0..1) of a PCM16 little-endian piece that is being played right now. */
    fun feedPcm(b: ByteArray, off: Int, len: Int) {
        var sum = 0.0
        var n = 0
        var i = off
        val end = off + len - 1
        while (i < end) {
            val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += s.toDouble() * s.toDouble()
            i += 2
            n++
        }
        if (n == 0) return
        val rms = Math.sqrt(sum / n) / 32768.0
        realLevel = Math.min(1.0, Math.sqrt(rms * 6.0)).toFloat() // shaped so normal speech reaches ~0.5-1.0
        realAt = SystemClock.uptimeMillis()
    }

    fun refresh() {
        val st = Meera.settings
        gain = st.auraStrength.coerceIn(1, 10) / 6f
        val mode = st.auraMode
        val active = state.value != AuraState.OFF && mode != "off"
        val wantOverlay = active && mode == "phone" && !overlayFailed && canShowOverPhone()
        if (wantOverlay) addOverlay() else removeOverlay()
        inApp.value = active && overlay == null
    }

    private fun addOverlay() {
        if (overlay != null) return
        try {
            // normal overlay permission if granted, otherwise the Accessibility service's own overlay window
            val svc = MeeraAccessibilityService.instance
            val ctx: Context = (if (!canDrawOverlays()) svc else null) ?: app
            val viaA11y = ctx !== app
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = AuraView(ctx)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                if (viaA11y) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or // touches go straight through to the app below
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            wm.addView(v, lp)
            overlay = v
            overlayWm = wm
        } catch (e: Exception) {
            overlayFailed = true // fall back to the in-app border
            overlay = null
        }
    }

    private fun removeOverlay() {
        val v = overlay ?: return
        try {
            (overlayWm ?: (app.getSystemService(Context.WINDOW_SERVICE) as WindowManager)).removeView(v)
        } catch (e: Exception) { }
        overlay = null
        overlayWm = null
    }
}
