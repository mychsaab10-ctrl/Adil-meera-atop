package com.meera.ai.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.meera.ai.Meera
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.GeminiException
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import com.meera.ai.eyes.EyesCommands
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** role: "user" | "model" | "system" (system = tool results / notices) */
class UiMsg(val role: String, val text: String)

class ChatSession(val kind: String) {
    val messages = mutableStateListOf<UiMsg>()
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var searchMode by mutableStateOf(false)
    private var job: Job? = null

    private fun showMood(m: String) {
        if (kind == "coding") return
        Meera.setMood(m)
        Meera.scope.launch {
            delay(9000)
            if (Meera.mood.value == m) Meera.setMood("normal") // back to normal after a few seconds
        }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        error = null
        Meera.lastUserText = t
        messages.add(UiMsg("user", t))

        // A pending question from Meera ("yaad rakh loon?", "bhej doon?") is answered here, not by Gemini.
        if (kind != "coding") {
            val answer = Meera.interceptAnswer(t)
            if (answer != null) {
                messages.add(UiMsg("model", answer))
                showMood(Mood.guess(answer))
                return
            }
        }

        // "Meera open your eyes" / "aankhein band karo" / "camera on|off": matched here, never sent to Gemini.
        if (kind == "chat") {
            val cmd = EyesCommands.match(t)
            if (cmd != null) {
                val reply = Meera.eyes.runCommand(cmd)
                messages.add(UiMsg("model", reply))
                showMood(Mood.guess(reply))
                return
            }
        }

        busy = true
        if (kind != "coding") Meera.setMood("thinking")
        job = Meera.scope.launch {
            try {
                val s = Meera.settings
                val history = messages.filter { it.role != "system" }.takeLast(30).map { ChatMsg(it.role, it.text) }
                val coding = kind == "coding"
                val tools = when {
                    coding -> null
                    searchMode -> Persona.searchTools
                    else -> Persona.tools
                }
                val temp = if (coding) 0.3 else s.temperature.toDouble()
                val r = Meera.gemini.generate(s.model, Persona.system(kind), history, temp, tools = tools)
                val (clean, tagged) = Mood.split(r.text)
                val sb = StringBuilder(clean)
                if (r.sources.isNotEmpty()) sb.append("\n\nSources:\n").append(r.sources.joinToString("\n") { "• $it" })
                if (sb.isNotBlank()) messages.add(UiMsg("model", sb.toString()))
                r.calls.forEach { c ->
                    val out = Meera.handleCall(c.name, c.args)
                    // a question for the user is shown as a normal Meera message, results as a small system line
                    if (out.ask) messages.add(UiMsg("model", out.text)) else messages.add(UiMsg("system", "⚙ " + out.text))
                }
                showMood(tagged ?: Mood.guess(clean))
                if (s.autoSpeak && clean.isNotBlank()) Meera.tts.speak(clean)
            } catch (e: GeminiException) {
                error = e.message
                if (kind != "coding") Meera.setMood("sad")
            } finally {
                busy = false
            }
        }
    }

    fun stop() {
        job?.cancel(); busy = false
        if (kind != "coding") Meera.setMood("normal")
    }

    fun clear() {
        stop(); messages.clear(); error = null
    }

    /** Asks Gemini for a short summary, then Meera asks "save kar loon?" in the chat. */
    fun saveSummary() {
        if (messages.none { it.role == "user" } || busy) return
        busy = true
        Meera.scope.launch {
            try {
                val s = Meera.settings
                val convo = messages.filter { it.role != "system" }.takeLast(30)
                    .joinToString("\n") { (if (it.role == "user") "User: " else "Meera: ") + it.text }
                val r = Meera.gemini.generate(
                    s.model, null,
                    listOf(ChatMsg("user", "Summarize the useful, lasting points of this conversation in 2-3 short sentences. Leave out passwords, OTPs and ID numbers.\n\n$convo")),
                    0.2
                )
                val sum = Mood.strip(r.text)
                if (sum.isNotBlank()) {
                    val out = Meera.confirmThen("Is summary ko memory me save kar loon? (haan / nahi)") {
                        Meera.memory.add("summary", sum)
                        "Summary memory me save kar di."
                    }
                    messages.add(UiMsg("model", sum + "\n\n" + out.text))
                }
            } catch (e: GeminiException) {
                error = e.message
            } finally {
                busy = false
            }
        }
    }
}
