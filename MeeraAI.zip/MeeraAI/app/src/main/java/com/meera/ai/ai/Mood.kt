package com.meera.ai.ai

/** Avatar moods. Chat replies carry a hidden [[MOOD: x]] tag; voice replies are guessed from the words. */
object Mood {
    val all = listOf("normal", "happy", "excited", "sad", "loving", "thinking")
    private val tag = Regex("""\[\[\s*MOOD\s*:\s*([A-Za-z]+)\s*]]""", RegexOption.IGNORE_CASE)

    /** Returns (text without the tag, mood from tag or null). */
    fun split(text: String): Pair<String, String?> {
        val m = tag.find(text)
        val mood = m?.groupValues?.get(1)?.lowercase()?.takeIf { it in all }
        return text.replace(tag, "").trim() to mood
    }

    fun strip(text: String): String = text.replace(tag, "").trim()

    fun guess(text: String): String {
        val t = text.lowercase()
        fun any(vararg k: String) = k.any { t.contains(it) }
        return when {
            any("love", "pyaar", "pyar", "miss you", "jaan", "dil se", "❤", "💜", "😘", "🥰") -> "loving"
            any("sorry", "maaf", "dukh", "udaas", "afsos", "bura lag", "sad ", "😢", "😔", "🥺") -> "sad"
            any("wow", "amazing", "congrat", "mubarak", "badhai", "yay", "kamaal", "zabardast", "🎉", "🤩") -> "excited"
            any("haha", "hehe", "khush", "great", "badhiya", "mazza", "maza", "😊", "😄", "😂") -> "happy"
            any("hmm", "soch", "let me think", "dekhte hain", "shayad", "maybe", "perhaps") -> "thinking"
            else -> "normal"
        }
    }
}
